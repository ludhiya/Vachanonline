import React from 'react';

import './App.css';
import ControlledCarousel from './components/ControlledCarousel';


function App() {
  return (
    <>
      <div className="container">
       <ControlledCarousel />
       </div>
   </>
  );
}

export default App;
